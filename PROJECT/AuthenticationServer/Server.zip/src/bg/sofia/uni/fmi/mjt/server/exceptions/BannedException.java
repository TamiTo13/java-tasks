package bg.sofia.uni.fmi.mjt.server.exceptions;

public class BannedException extends RuntimeException {
    public BannedException(String message) {
        super(message);
    }
}
