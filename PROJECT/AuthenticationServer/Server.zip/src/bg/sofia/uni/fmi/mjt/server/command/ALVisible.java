package bg.sofia.uni.fmi.mjt.server.command;

public interface ALVisible extends Command {
    //Marks the command whose execution will be noted on the audit log
}
