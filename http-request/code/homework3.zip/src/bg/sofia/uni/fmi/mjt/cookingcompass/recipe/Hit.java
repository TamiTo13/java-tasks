package bg.sofia.uni.fmi.mjt.cookingcompass.recipe;

public record Hit(Recipe recipe) {
}
